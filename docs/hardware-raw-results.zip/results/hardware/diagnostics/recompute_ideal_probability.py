#!/usr/bin/env python
"""Recompute the ideal QAOA candidate probability and compare with hardware counts.

Run from the CAF-main package root (or anywhere; paths are resolved from this file):
    /data/yxg/envs/caf_v2/bin/python results/hardware/diagnostics/recompute_ideal_probability.py
"""
from __future__ import annotations

import glob
import json
import sys
from pathlib import Path

import numpy as np
from scipy.stats import binom

CAF_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(CAF_ROOT))

from caf_core import evaluate_state_vector  # noqa: E402
from experiments._common import load_upstream_components  # noqa: E402
from experiments.quantum.run_hardware_qaoa import _relax  # noqa: E402
from experiments.quantum.run_qaoa import QAOAConfig, QiskitQAOAOptimizer  # noqa: E402

QPU_DIR = CAF_ROOT / "results" / "hardware" / "qpu"
OUT_DIR = CAF_ROOT / "results" / "hardware"
SHOTS = 4000


def _index_in_var_order(cand_community, labels, var_labels):
    values = {labels[j]: int(cand_community[j]) for j in range(len(labels))}
    bits = [values[label] for label in var_labels]
    return sum(bit << pos for pos, bit in enumerate(bits))


def main():
    Clustering, Denoiser, SA, Pipeline, get_model, rebal = load_upstream_components(None)
    del Clustering, Denoiser, SA, Pipeline, rebal

    ideal_rows, diag_rows = [], []
    for path in sorted(glob.glob(str(QPU_DIR / "HW_qaoa_submit_*.json")),
                       key=lambda p: json.load(open(p))["community"]):
        record = json.load(open(path))
        n, K, q = record["n"], record["K"], record["q_eff"]
        adjusted = np.asarray(record["adjusted_returns"], dtype=float)
        sub = np.asarray(record["local_covariance"], dtype=float)
        model, weights = get_model(adjusted, sub, budget=K, risk_factor=q)
        labels = [weights[j].name for j in range(n)]

        relaxed = _relax(adjusted, sub, K, q)
        warmstart = {labels[j]: float(relaxed[j]) for j in range(n)}
        cfg = QAOAConfig(
            p=record["p"], restarts=record["qaoa_restarts"], maxiter=record["qaoa_maxiter"],
            seed=record["base_seed"], optimizer="COBYLA", shots=record["shots"],
            decode="shots", warmstart=record["warmstart"],
        )
        opt = QiskitQAOAOptimizer(cfg, warmstart_c=warmstart)
        solution, _, _ = opt(model, weights)
        probs = np.asarray(opt.last_probs, dtype=float)
        var_labels = record["var_labels"]
        dim = 1 << n

        sim = np.asarray(record["sim_candidate"], dtype=int)
        static = np.asarray(record["static_state"], dtype=int)[np.asarray(record["community_indices"], dtype=int)]
        sim_idx = _index_in_var_order(sim, labels, var_labels)
        static_idx = _index_in_var_order(static, labels, var_labels)

        counts = record["counts_full"]
        width = max(len(key) for key in counts)
        empirical = np.zeros(dim, dtype=float)
        for key, value in counts.items():
            bits = key.zfill(width)
            index = sum(int(bits[width - 1 - i]) << i for i in range(n))
            empirical[index] += value
        empirical /= empirical.sum()

        feasible_masks = [mask for mask in range(dim) if mask.bit_count() == K]
        max_feasible_mask = max(feasible_masks, key=lambda mask: probs[mask])
        uniform_mass = len(feasible_masks) / dim
        p_ideal = float(probs[sim_idx])
        observed = int(round(empirical[sim_idx] * SHOTS))
        expected = SHOTS * p_ideal
        binom_p = float(binom.cdf(observed, SHOTS, p_ideal)) if p_ideal > 0 else 0.0

        ideal_rows.append({
            "community": record["community"], "n": n, "K": K,
            "rerun_solution_matches": bool(np.array_equal(np.asarray(solution, dtype=int), sim)),
            "p_ideal": p_ideal, "expected_hits": float(expected), "observed_hits": observed,
            "observed_over_expected": float(observed / expected) if expected else None,
            "p_static": float(probs[static_idx]),
            "max_feasible_p": float(probs[max_feasible_mask]),
            "max_feasible_bits_var_order": [int((max_feasible_mask >> i) & 1) for i in range(n)],
        })
        diag_rows.append({
            "community": record["community"], "n": n, "K": K,
            "p_ideal": p_ideal, "expected_hits": float(expected), "observed_hits": observed,
            "binomial_p_leq_observed": binom_p,
            "tv_hw_ideal": float(0.5 * np.abs(empirical - probs).sum()),
            "tv_hw_uniform": float(0.5 * np.abs(empirical - np.full(dim, 1.0 / dim)).sum()),
            "feasible_fraction_hw": float(empirical[feasible_masks].sum()),
            "feasible_fraction_uniform": float(uniform_mass),
            "max_feasible_p": float(probs[max_feasible_mask]),
        })
        print(f"c{record['community']}: p_ideal={p_ideal:.6g} expected={expected:.1f} "
              f"observed={observed} TV_ideal={diag_rows[-1]['tv_hw_ideal']:.4f} "
              f"TV_uniform={diag_rows[-1]['tv_hw_uniform']:.4f}")

    (OUT_DIR / "ideal_probability_20261023.json").write_text(
        json.dumps(ideal_rows, indent=2), encoding="utf-8")
    (OUT_DIR / "hardware_distribution_diagnostic_20261023.json").write_text(
        json.dumps(diag_rows, indent=2), encoding="utf-8")
    print("wrote ideal_probability_20261023.json and hardware_distribution_diagnostic_20261023.json")


if __name__ == "__main__":
    main()
