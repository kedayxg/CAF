#!/usr/bin/env python
"""Uniform-sampling control for the best-of-feasible-sample hardware criterion.

For each community, draw 4000 states uniformly from all 2^n bitstrings, keep the
feasible states, and record the best global objective change. Repeat 2000 times.

Run from the CAF-main package root:
    /data/yxg/envs/caf_v2/bin/python results/hardware/diagnostics/uniform_bestofsample_control.py
"""
from __future__ import annotations

import glob
import json
import sys
from pathlib import Path

import numpy as np

CAF_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(CAF_ROOT))

QPU_DIR = CAF_ROOT / "results" / "hardware" / "qpu"
OUT_DIR = CAF_ROOT / "results" / "hardware"
SHOTS = 4000
TRIALS = 2000
RNG = np.random.default_rng(20261023)


def main():
    rows = []
    for path in sorted(glob.glob(str(QPU_DIR / "HW_qaoa_submit_*.json")),
                       key=lambda p: json.load(open(p))["community"]):
        record = json.load(open(path))
        n, K = record["n"], record["K"]
        cov = np.asarray(record["covariance"], dtype=float)
        ret = np.asarray(record["expected_returns"], dtype=float)
        base = np.asarray(record["static_state"], dtype=int)
        community = np.asarray(record["community_indices"], dtype=int)
        q = record["risk_factor"]
        base_obj = record["static_objective"]
        dim = 1 << n

        d_objectives = np.empty(dim, dtype=float)
        for mask in range(dim):
            state = base.copy()
            state[community] = [(mask >> i) & 1 for i in range(n)]
            d_objectives[mask] = (q * state @ cov @ state - ret @ state) - base_obj
        sim = np.asarray(record["sim_candidate"], dtype=int)
        sim_index = sum(int(bit) << i for i, bit in enumerate(sim))
        feasible = np.array([mask for mask in range(dim) if mask.bit_count() == K])

        best_values, hits = [], 0
        for _ in range(TRIALS):
            sampled = RNG.integers(0, dim, size=SHOTS)
            sampled = sampled[np.isin(sampled, feasible)]
            if sampled.size == 0:
                continue
            best = sampled[np.argmin(d_objectives[sampled])]
            best_values.append(d_objectives[best])
            hits += int(best == sim_index)

        row = {
            "community": record["community"], "n": n, "K": K,
            "sim_dO": float(d_objectives[sim_index]),
            "uniform_P_best_equals_sim": hits / TRIALS,
            "uniform_best_dO_mean": float(np.mean(best_values)),
            "uniform_best_dO_sd": float(np.std(best_values)),
            "uniform_best_dO_q05": float(np.quantile(best_values, 0.05)),
            "uniform_best_dO_q95": float(np.quantile(best_values, 0.95)),
        }
        rows.append(row)
        print(row)

    (OUT_DIR / "uniform_bestofsample_control_20261023.json").write_text(
        json.dumps(rows, indent=2), encoding="utf-8")

    baseline = {}
    baseline_rng = np.random.default_rng(7)
    for n in (8, 10, 14):
        dim = 1 << n
        values = []
        for _ in range(500):
            sampled = baseline_rng.integers(0, dim, size=SHOTS)
            empirical = np.bincount(sampled, minlength=dim) / SHOTS
            values.append(float(0.5 * np.abs(empirical - 1.0 / dim).sum()))
        baseline[str(n)] = {
            "mean": float(np.mean(values)), "sd": float(np.std(values)),
            "q95": float(np.quantile(values, 0.95)),
        }
    (OUT_DIR / "uniform_tv_finite_sample_baseline.json").write_text(
        json.dumps(baseline, indent=2), encoding="utf-8")
    print("wrote uniform_bestofsample_control_20261023.json and uniform_tv_finite_sample_baseline.json")


if __name__ == "__main__":
    main()
