# arXiv revision source

The user supplied `QAPP_914.zip`. Original file hashes are preserved in
`original-source-sha256.json`; the uploaded archive itself is unchanged.
`main.tex` contains the revised method, guarantee and complexity discussion.
`revision_results.tex` is generated from recorded experiments; it does not
inherit the original tables or numerical figures.

The revision uses only igraph Newman, with community capacity 100 for classical
experiments and 16 for the N=40 statevector study. Oversized induced subgraphs
are repartitioned until they fit; the library default capacity zero remains
available for unrestricted reference studies. It aligns local/global q in the
frozen control. `--local-risk-rebalancing` is an explicit optional surrogate
setting, not the default frozen protocol. Historical hardware evidence is
explicitly identified as a v1 fixed-instance report, with no fresh QPU claim.
The original hardware count archive was not included in the supplied source.
Unused original PNG figures are retained as uploaded reference files; they are
excluded from the revision source package.

The primary classical backend is now Gurobi, with one fixed-configuration flow
per panel and a separate repeated-unshifted-model control. All original SA
results remain as backend sensitivity, including the 2018 injection-ablation result.
The primary emphasis was selected after observing those controls. The previous
SA-primary PDF/source are preserved in `archive/`.

Generate the results section after completing the offline runs:

```bash
python manuscript/run_sampling_control.py --results revision_results_v2 --out-dir sampling_controls_v2 --workers 4
python manuscript/run_gurobi_main.py --results revision_results_v2 --out-dir gurobi_main_v2
python manuscript/validate_gurobi_main.py --results gurobi_main_v2 --sa-results revision_results_v2
python manuscript/run_coordination_study.py --out-dir coordination_study_v2
python manuscript/validate_coordination_study.py --results coordination_study_v2
python manuscript/validate_revision.py --results revision_results_v2 --frozen /path/to/S0_freeze_control.json
python manuscript/build_revision.py --results revision_results_v2 --frozen /path/to/S0_freeze_control.json
python manuscript/package_revision.py
```

`build_revision.py` refuses a final build unless all 345 planned tasks are
present, the additional 40 sampling-matched controls are complete, and the two
Gurobi primary panels have matching independent validation.
`--allow-partial` is for internal working drafts only; it inserts a
visible draft notice. `package_revision.py` refuses incomplete evidence and
requires validation of the exact record hashes and frozen snapshot, and checks
the compiled log for undefined references/citations and overfull boxes.
TeX Live with IEEE-compatible fonts, `latexmk`, `bibtex`, `float`, `booktabs`,
`placeins`, `hyperref` and the standard AMS packages is required. The pseudocode
uses ordinary LaTeX lists inside a float, avoiding an extra algorithms package.

The validation script independently recomputes portfolio objectives from the
complete covariance matrices, reconstructs exact community membership and
budgets, checks histories and accepted deltas, replays the suppression diagnostic
using a direct external-portfolio multiplication, and enumerates frozen exact
moves. An optional partial audit produces an incomplete certificate which
cannot satisfy final packaging. The fresh batch already includes explicitly
configured finite-field SQA in its normal result directory.

The resulting PDF is for author review. The source ZIP includes its matching
`.bbl`, required figures and bibliography files. These scripts do not publish,
upload, replace the proceedings paper, or change arXiv account metadata.

Terminology: the unshifted control is CAF without injection, an internal
component ablation. It retains CAF's full-global objective verification and
greedy sequential acceptance. The 2018 SA comparison qualifies injection's
incremental benefit and is not an overall negative result for CAF. The shared
acceptance mechanism has not been independently ablated.

The final package also retains the 24 declared capacity/subset records and
matching independent validation. Latest-context sequential updates (cyclic
discrete BCD) are a supplementary update-timing ablation sharing CAF's partition,
budgets, local backend and acceptance rule. BCD remains a technical foundation;
the revision does not present this variant as a separate primary competing
pipeline. The study fixes six complete sweeps, disables patience for equal calls
and reports actual one/four-worker resources and all partition failures.
Final objectives match in 24/24 configurations, with no consistent local CPU
speedup. A short body paragraph points to the full appendix; these details are
not headline abstract or conclusion results. All SA injection ablations remain
explicit. The outcome-selected synthetic search is separate exploratory work
and is not included in the paper. This scope reduction reruns no experiments
and changes no core source, input data or experimental records.
